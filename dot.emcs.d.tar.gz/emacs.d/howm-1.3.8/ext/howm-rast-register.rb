#! /usr/bin/ruby
# shamelessly copied and modified from rast-0.1.1
#
# This file is not part of Rast.
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA

require "rast"

if ARGV.length < 2
  $stderr.printf("usage: %s <db> <query>\n", $0)
  exit(1)
end

dbpath = ARGV[0]
filename = File::expand_path ARGV[1];
query = "filename = #{filename}"

id = Rast::DB.open(dbpath, Rast::DB::RDONLY) do |db|
  result = db.search(query, {"properties" => ["filename"]})
  result.items.empty? ? nil : result.items[0].doc_id
end

properties = {
  "filename" => filename,
  "title" => filename,
  "last_modified" => File.mtime(filename).to_s,
  "filesize" => File.size(filename),
}
text = File.read(filename)

Rast::DB.open(dbpath, Rast::DB::RDWR) do |db|
  id ? db.update(id, text, properties) : db.register(text, properties)
end
