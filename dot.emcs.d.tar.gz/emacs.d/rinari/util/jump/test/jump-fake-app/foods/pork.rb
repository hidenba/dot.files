class Pork

  def cook_stomach
    # so much
  end

  def cook_butt
    # good stuff
  end
  
  def cook_outer_back
    # from one
  end
  
  def cook_inner_back
    # poor animal
  end
  
end
