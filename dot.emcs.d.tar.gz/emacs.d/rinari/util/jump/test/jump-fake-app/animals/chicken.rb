class Chicken
  
  def gizzards
    
  end
  
end
