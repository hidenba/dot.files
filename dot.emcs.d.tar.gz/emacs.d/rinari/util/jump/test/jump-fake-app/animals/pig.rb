class Pig
  
  def stomach
    puts "bacon comes from my belly"
  end
  
  def butt
    puts "ham comes from my butt"
  end
  
  def outer_back
    puts "my back has backfatt"
  end
  
  def inner_back
    puts "my back can be cut into chops"
  end
  
end
