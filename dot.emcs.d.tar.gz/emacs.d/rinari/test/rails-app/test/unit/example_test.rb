require File.dirname(__FILE__) + '/../test_helper'

class ExampleTest < ActiveSupport::TestCase
  # Replace this with your real tests.

  def test_to_s
    assert true
  end
  
end
