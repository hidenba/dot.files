require File.dirname(__FILE__) + '/../test_helper'

class UnitsControllerTest < ActionController::TestCase
  
  # Replace this with your real tests.
  def test_fall
    assert true
  end
  
end
