module NewoneHelper
end
