module ExampleHelper
end
