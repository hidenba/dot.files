class UnitsController < ApplicationController
  
  def fall
    render :layout => false
  end
  
end
