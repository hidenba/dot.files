class NewoneController < ApplicationController
end
