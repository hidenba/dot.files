class Example < ActiveRecord::Base

  def to_s
    ""
  end

end
